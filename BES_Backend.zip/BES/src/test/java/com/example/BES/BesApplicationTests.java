package com.example.BES;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BesApplicationTests {

	@Test
	void contextLoads() {
	}

}
